README

Course: cs400
Semester: Summer 2019
Project name: Milk Weight
Student Name: Zhe Wang

email: zwang2428@wisc.edu

Other notes or comments to the grader:

This Farm class was only created to provide some data example, and the 
examples are all hard-coded. 