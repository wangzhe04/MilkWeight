///////////////////////File Header///////////////////////////
//Author: Zhe Wang
//Email: zwang2428@wisc.edu
//Term: Summer2020
//Program purpose:This program create a GUI that allow user view 
//and edit data of milk weights of different farms
////////////////////////////////////////////////////////////
package application;

/**
 * This class was only created for data example 
 * the actual farm class would vary
 * @author 87179
 *
 */

public class Farm {
    private String month = null;
    private int weight = 0;
    private double percentage = 0;
    
    public Farm(String month, int weight, double d) {
    	this.month = month;
    	this.weight = weight;
    	this.percentage = d;
    }
    
    public String getMonth() {
    	return month;
    }
    public String setMonth() {
    	return month;
    }
    
    public int getWeight() {
    	return weight;
    }
    public void setWeight(int weight) {
    	this.weight = weight;
    }
    public double getPercentage() {
    	return percentage;
    }
       
    public void setWeight2(double percentage) {
    	this.percentage = percentage;
    }
}